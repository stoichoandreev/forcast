package forcast.sniper.com.forcast.converter

import javax.inject.Inject

import forcast.sniper.com.api.openweather.models.ForecastResponse
import forcast.sniper.com.forcast.viewmodels.MainActivityViewModel

class MainActivityViewModelConverter @Inject constructor() {

    fun extractFromForecastResponse(response: ForecastResponse): MainActivityViewModel {

        return MainActivityViewModel("", "")
    }

}
