package forcast.sniper.com.forcast.services

import android.content.Context
import io.reactivex.Observable
import io.reactivex.Scheduler
import java.io.IOException

class CityIdService(private val context: Context,
                    private val notifications: Scheduler,
                    private val worker: Scheduler) {

    fun read(cityName: String): Observable<String> {
        return getObservable(cityName)
                .subscribeOn(worker)
                .observeOn(notifications)
    }

    private fun getObservable(cityName: String): Observable<String> {
        return Observable.create { subscriber ->
            if (!subscriber.isDisposed) {
                val cityId = findCityId(cityName)
                subscriber.onNext(cityId);
                subscriber.onComplete()
            }
        }
    }

    private fun findCityId(cityName: String): String {
        var json: String?
        try {
            val input = context.assets.open("city.list.json")
            val size = input.available()
            val buffer = ByteArray(size)
            input.read(buffer)
            input.close()
//            json = String(buffer, "UTF-8")
//            val data = Gson().fromJson(json, Data::class.java)
        } catch (ex: IOException) {
            ex.printStackTrace()
        }
        return ""

    }

}
