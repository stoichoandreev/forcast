package forcast.sniper.com.api

interface ApiConfiguration {
    val baseURL: String
}
