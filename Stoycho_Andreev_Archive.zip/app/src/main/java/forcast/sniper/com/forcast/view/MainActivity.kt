package forcast.sniper.com.forcast.view

import android.Manifest
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Toast
import com.tbruyelle.rxpermissions2.RxPermissions
import forcast.sniper.com.forcast.ForCastApplication
import forcast.sniper.com.forcast.R
import forcast.sniper.com.forcast.mvp.MainActivityPresenter
import forcast.sniper.com.forcast.viewmodels.MainActivityViewModel
import kotlinx.android.synthetic.main.activity_main.*
import javax.inject.Inject

class MainActivity : AppCompatActivity(), MainActivityPresenter.View {

    @Inject
    lateinit var presenter: MainActivityPresenter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        inject()

        askLocationPermissions()

    }

    override fun onResume() {
        super.onResume()
        presenter.attachView(this)
    }

    override fun onPause() {
        super.onPause()
        presenter.detachView()
    }

    private fun askLocationPermissions() {
        val rxPermissions = RxPermissions(this)
        rxPermissions.request(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                .subscribe { granted ->
                    if (granted!!) {
                        no_location.visibility = View.GONE
                        forecast_view_container.visibility = View.VISIBLE
                        presenter.fetchForecast("London")
                    } else {
                        showLocationPermissionsDenied()
                        no_location.visibility = View.VISIBLE
                        forecast_view_container.visibility = View.GONE
                    }
                }
    }

    private fun showLocationPermissionsDenied() {
        Toast.makeText(this, "Location permissions needed", Toast.LENGTH_LONG).show()
    }

    private fun inject() {
        DaggerMainActivityComponent.builder()
                .applicationComponent(ForCastApplication.getApplicationComponent())
                .build()
                .inject(this)
    }

    override fun showForecastResult(result: MainActivityViewModel) {
        city_name_view.text = result.city
        forecast_view.text = result.forecast
    }
}
