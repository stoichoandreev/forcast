package forcast.sniper.com.forcast.viewmodels

data class MainActivityViewModel(val city: String, val forecast: String)
