package forcast.sniper.com.forcast.mvp

import forcast.sniper.com.forcast.services.CityIdService
import forcast.sniper.com.forcast.services.MainActivityForecastService
import io.reactivex.disposables.CompositeDisposable

class MainActivityPresenterImp constructor(private var view: MainActivityPresenter.View? = null,
                                           private val remoteForecastService: MainActivityForecastService,
                                           private val cityIdService: CityIdService,
                                           private val disposables: CompositeDisposable) : MainActivityPresenter {

    override fun attachView(view: MainActivityPresenter.View) {
        this.view = view
    }

    override fun detachView() {
        this.view = null
    }

    override fun fetchForecast(cityName: String) {
        disposables.add(cityIdService.read(cityName)
                .flatMap { cityId -> remoteForecastService.getForecast(cityId) }
                .subscribe { response -> view?.showForecastResult(response) })
    }

}
